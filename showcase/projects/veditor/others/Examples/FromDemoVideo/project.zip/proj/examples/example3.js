// On Region Update Attempt
function (updateDetails, current, trail, region)
{
    if (trail[region.name])
        return 'BLOCK';

    trail[region.name] = true;
    return 'ALLOW';
}

// On Region Update Completion
function (updateDetails, previous, current, trail, region)
{
    if (previous != current)
        return 'PROPAGATE';
    else
        return;
}

// Bind
function (args, current, trail, region)
{
    let [lvalue] = args;
    return lvalue;
}
