// On Update Attempt
function (updateDetails, current, trail, region)
{
    if (updateDetails.type == 'INSERT')
        if (updateDetails.char.match(/[0-9]/) != null)
            return 'ALLOW';
        else
            return 'BLOCK';
    else if(updateDetails.type == 'DELETE')
        if (current.length > 1)
            return 'ALLOW';
        else
            return 'BLOCK';
    else
        return 'BLOCK';
}

// On Update Completion
function (updateDetails, previous, current, trail, region)
{
    return;
}
