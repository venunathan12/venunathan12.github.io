// On Update Attempt
function (updateDetails, current, trail, region)
{
    console.log('Update Attempted !');
    return 'ALLOW';
}

// On Update Completion
function (updateDetails, previous, current, trail, region)
{
    console.log('Update Completed !');
}
