// On Region Update Attempt
function (updateDetails, current, trail, region)
{
    return 'ALLOW';
}

// On Region Update Completion
function (updateDetails, previous, current, trail, region)
{
    return 'PROPAGATE';
}

// On Output Update Attempt
function (updateDetails, current, trail, region)
{
    if (updateDetails.type == 'BIND')
        return 'ALLOW';
    else
        return 'BLOCK';
}

// On Output Update Completion
function (updateDetails, previous, current, trail, region)
{}

// Bind
function (args, current, trail, region)
{
    let [cols, conds] = args;
    cols = cols.slice(1).trim();
    conds = conds.slice(1).trim();
 
    let query = `SELECT\n` +
                `    ${cols}\n` +
                `FROM\n` +
                `    table1 t1, table2 t2, table3 t3\n` +
                `WHERE\n` +
                `    (t1.__t2join = t2.__t1join AND t1.__t3join = t3.__t1join)\n` +
                `    ${conds != '' ? 'AND ' + conds : ''}`;
 
    return query;
}
